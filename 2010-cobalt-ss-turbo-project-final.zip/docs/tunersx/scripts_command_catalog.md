# Scripts + command catalog (allowlist-first)

Every command:
- has risk class
- supports dry-run
- enforces preconditions
- emits audit records

OEM work (if authorized) is capture/pack/review oriented, not writer automation.
