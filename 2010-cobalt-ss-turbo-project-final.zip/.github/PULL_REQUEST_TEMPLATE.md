---
name: Pull request
about: Submit changes to the documentation or build log
---

**Summary of changes**

Provide a summary of what this pull request adds or changes.  List affected files and briefly describe modifications.

**Motivation**

Explain the reason for these changes.  Did you fix an error, add a new procedure, or update performance data?  Include any relevant test results or observations.

**Checklist**

- [ ] I have reviewed the `CONTRIBUTING.md` guidelines.
- [ ] My commit history is clean and descriptive.
- [ ] I have updated `CHANGELOG.md` as needed.
- [ ] All documents render correctly in Markdown preview.