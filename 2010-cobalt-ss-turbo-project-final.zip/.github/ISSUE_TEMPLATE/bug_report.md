---
name: Bug report
about: Create a report to help us improve the documentation or procedures
title: "Bug: "
labels: bug
assignees: ''
---

**Describe the problem**
A clear and concise description of what is wrong.  Include which document/section is affected and what the expected behaviour or information should be.

**Steps to reproduce**
1. Go to the file or procedure that contains the issue.
2. Describe the steps you followed.
3. Highlight the discrepancy or error.

**Expected behaviour**
Describe what you expected to happen.  Include correct values, torque specs or procedure steps if known.

**Additional context**
Add any other context about the problem here, such as vehicle configuration, mileage, or supporting logs/photos.