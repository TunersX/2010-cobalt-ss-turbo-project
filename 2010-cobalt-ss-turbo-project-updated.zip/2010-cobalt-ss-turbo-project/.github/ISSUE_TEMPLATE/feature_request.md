---
name: Feature request
about: Suggest an idea for new documentation, modification, or performance goal
title: "Feature request: "
labels: enhancement
assignees: ''
---

**Describe the desired improvement**
Provide a clear and concise description of what you would like added or improved.  For example, propose a new maintenance guide, a performance mod write‑up, or a tuning strategy.

**Rationale**
Explain why this feature would be beneficial.  How does it improve reliability, performance, or usability?  If applicable, link to discussions or data supporting the request.

**Additional context**
Add any other context, such as part numbers, dyno graphs, or personal experience.